const express = require("express");
const app = express();
const connectDatabase = require('./config/database')
const cloudinary = require('cloudinary').v2;
const cors = require('cors')
require('dotenv').config();
const cookieParser = require('cookie-parser');

// Middleware
app.use(cookieParser());
app.use(express.json({limit:'50mb'}));
app.use(express.urlencoded({limit: "50mb", extended: true }));

// Port configuration
const PORT = process.env.PORT || 5000;

// CORS configuration - Replace this section
const corsOptions = {
    origin: process.env.NODE_ENV === 'production' 
        ? [process.env.FRONTEND_URL, 'https://fragnifique-axios.onrender.com'] 
        : '*',
    credentials: true,
};
app.use(cors(corsOptions));

// Import routes
const auth = require('./routes/auth');
const product = require('./routes/Product');
const certification = require('./routes/certificationRoutes');
const cart = require('./routes/cartRoutes');
const orderRoutes = require('./routes/orderRoutes');
const promotionRoutes = require('./routes/promotionRoutes');

// Connect to database
connectDatabase();

// Configure cloudinary
cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET
});

// Register routes
app.use('/api/', auth);
app.use('/api/', product);
app.use('/api/', certification);
app.use('/api/', cart);
app.use('/api/orders', orderRoutes);
app.use('/api/', promotionRoutes);


// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        success: false,
        message: 'Internal server error',
        error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});

// Update the listen callback
app.listen(PORT, () => {
    console.log(`✅ Server running on port ${PORT}`);
});

