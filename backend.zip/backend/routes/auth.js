const express = require('express');
const router = express.Router();
const { 
  registerUser, 
  loginUser, 
  logout, 
  getUserProfile, 
  updateProfile, 
  updatePassword,
  savePushToken
} = require('../controllers/auth');
const { isAuthenticatedUser } = require('../middlewares/auth');
const multer = require('multer');

// Configure multer for memory storage
const upload = multer({ storage: multer.memoryStorage() });

router.post('/register', upload.single('avatar'), registerUser);
router.post('/login', loginUser);
router.get('/logout', logout);
router.get('/me', isAuthenticatedUser, getUserProfile);
router.put('/me/update', isAuthenticatedUser, updateProfile);
router.put('/me/update/password', isAuthenticatedUser, updatePassword);

// Add this route for saving push notification token
router.post('/saveToken', isAuthenticatedUser, savePushToken);

module.exports = router;