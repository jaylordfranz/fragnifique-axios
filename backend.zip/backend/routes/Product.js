const express = require('express');
const router = express.Router();
const upload = require("../utils/multer");
const { isAuthenticatedUser, authorizeRoles } = require('../middlewares/auth');
const {
  getProducts,
  getAdminProducts,
  deleteProduct,
  newProduct,
  updateProduct,
  getSingleProduct,
  createProductReview,
  getUserReviewForProduct,
  getProductReviews,
  deleteReview
} = require('../controllers/Product');


// Review routes
router.post('/product/:productId/review', isAuthenticatedUser, createProductReview);
router.get('/product/:productId/user-review', isAuthenticatedUser, getUserReviewForProduct);
router.get('/product/:productId/reviews', getProductReviews);
router.delete('/review/:reviewId', isAuthenticatedUser, authorizeRoles('admin'), deleteReview);
// User routes
router.get('/products', getProducts);
router.get('/product/:id', getSingleProduct);

// Admin routes: Create, Update, Delete Products
router.get('/admin/products', isAuthenticatedUser, authorizeRoles('admin'), getAdminProducts);
router.put('/admin/product/:id', isAuthenticatedUser, authorizeRoles('admin'), upload.array('images', 10), updateProduct);
router.delete('/admin/product/:id', isAuthenticatedUser, authorizeRoles('admin'), deleteProduct);
router.post('/admin/product/new', isAuthenticatedUser, authorizeRoles('admin'), upload.array('images', 10), newProduct);

// // Review routes
// router.post('/product/:productId/review', isAuthenticatedUser, createProductReview);
// router.delete('/review/:reviewId', isAuthenticatedUser, authorizeRoles('admin'), deleteReview);

module.exports = router;