const express = require('express');
const router = express.Router();
const orderController = require('../controllers/OrderController');
const { isAuthenticatedUser, authorizeRoles } = require('../middlewares/auth');

// MOST SPECIFIC ROUTES FIRST
// Admin routes with clearer path to avoid conflicts
router.get('/admin/all', isAuthenticatedUser, authorizeRoles('admin'), orderController.getAllOrders);
router.put('/admin/update/:id', isAuthenticatedUser, authorizeRoles('admin'), orderController.adminUpdateOrderStatus);

// Then general routes
router.post('/', isAuthenticatedUser, orderController.createOrder);
router.get('/', isAuthenticatedUser, orderController.getUserOrders);

// ID routes last to prevent conflicts
router.get('/:id', isAuthenticatedUser, orderController.getOrderById);
router.put('/:id', isAuthenticatedUser, orderController.updateOrder);

module.exports = router;