const express = require('express');
const router = express.Router();
const { isAuthenticatedUser } = require('../middlewares/auth');
const { updateNotificationToken } = require('../controllers/userController');

router.post('/notification-token', isAuthenticatedUser, updateNotificationToken);

module.exports = router;