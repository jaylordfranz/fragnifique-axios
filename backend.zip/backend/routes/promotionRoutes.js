const express = require('express');
const router = express.Router();
const {
  createPromotion,
  getAllPromotions,
  getPromotion,
  updatePromotion,
  deletePromotion
} = require('../controllers/promotionController');
const { isAuthenticatedUser, authorizeRoles } = require('../middlewares/auth');

router.route('/promotions')
  .get(getAllPromotions)
  .post(isAuthenticatedUser, authorizeRoles('admin'), createPromotion);

router.route('/promotions/:id')
  .get(getPromotion)
  .put(isAuthenticatedUser, authorizeRoles('admin'), updatePromotion)
  .delete(isAuthenticatedUser, authorizeRoles('admin'), deletePromotion);

module.exports = router;