const express = require('express');
const router = express.Router();
const upload = require("../utils/multer");

const { getCertifications, getSingleCertification,
    getAdminCertifications,
    deleteCertification,
    newCertification,
    updateCertification,

 } = require('../controllers/certificationController');
 const { isAuthenticatedUser, authorizeRoles } = require('../middlewares/auth');

router.get('/certifications', getCertifications)
router.get('/certification/:id', getSingleCertification)
router.get('/admin/certifications', isAuthenticatedUser, authorizeRoles('admin'), getAdminCertifications);
router.put('/admin/certification/:id', isAuthenticatedUser, authorizeRoles('admin'), upload.array('images', 10), updateCertification);
router.delete('/admin/certification/:id', isAuthenticatedUser, authorizeRoles('admin'), deleteCertification);
router.post('/admin/certification/new', isAuthenticatedUser, authorizeRoles('admin'), upload.array('images', 10), newCertification);

module.exports = router