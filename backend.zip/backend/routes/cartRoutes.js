const express = require('express');
const router = express.Router();
const { isAuthenticatedUser } = require('../middlewares/auth');
const cartController = require('../controllers/cartController'); // Import the full controller

// Routes with proper imports
router.post('/cart', isAuthenticatedUser, cartController.addToCart);
router.get('/cart', isAuthenticatedUser, cartController.getCart);
router.post('/cart/clear', isAuthenticatedUser, cartController.clearCart);
router.delete('/cart', isAuthenticatedUser, cartController.removeFromCart);

module.exports = router;