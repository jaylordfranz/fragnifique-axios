const jwt = require('jsonwebtoken');
const User = require('../models/user');

// Middleware to check if user is authenticated
const isAuthenticatedUser = async (req, res, next) => {
  const token = req.header('Authorization') ? req.header('Authorization').split(' ')[1] : null;  // Extract token from Authorization header

  if (!token) {
    return res.status(401).json({ success: false, message: 'Not authorized, no token' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET); // Verify the token
    req.user = await User.findById(decoded.id); // Get user from the decoded token
    next(); // Proceed to the next middleware or route handler
  } catch (error) {
    return res.status(401).json({ success: false, message: 'Not authorized, token failed' });
  }
};

// Middleware to authorize user roles
const authorizeRoles = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: `Role (${req.user.role}) is not allowed to access this resource` });
    }
    next(); // Proceed to the next middleware or route handler
  };
};

module.exports = { isAuthenticatedUser, authorizeRoles };
