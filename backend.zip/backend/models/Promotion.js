const mongoose = require('mongoose');

const promotionSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  title: {
    type: String,
    required: [true, 'Please enter promotion title'],
    trim: true,
    maxLength: [100, 'Promotion title cannot exceed 100 characters']
  },
  description: {
    type: String,
    required: [true, 'Please enter promotion description']
  },
  discountPercentage: {
    type: Number,
    required: [true, 'Please enter discount percentage'],
    min: [1, 'Discount must be at least 1%'],
    max: [100, 'Discount cannot exceed 100%']
  },
  startDate: {
    type: Date,
    required: [true, 'Please enter start date'],
    default: Date.now
  },
  endDate: {
    type: Date,
    required: [true, 'Please enter end date']
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Promotion', promotionSchema);