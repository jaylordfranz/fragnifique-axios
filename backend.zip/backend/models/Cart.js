const mongoose = require('mongoose');

const cartSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  items: [
    {
      product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
        required: true,
      },
      quantity: {
        type: Number,
        required: true,
        min: [1, 'Quantity cannot be less than 1'],
      },
      isOffline: {
        type: Boolean,
        default: false
      }
    },
  ],
});

// Custom population handling for carts
cartSchema.pre('findOne', function(next) {
  this.populate({
    path: 'items.product',
    options: { strictPopulate: false }
  });
  next();
});

// Post-find middleware to handle missing products
cartSchema.post('findOne', function(result, next) {
  if (result) {
    // Check each item to see if the product exists
    result.items.forEach(item => {
      // If product doesn't exist (failed to populate)
      if (!item.product || typeof item.product === 'string') {
        item.isOffline = true;
        item.product = {
          _id: item.product || mongoose.Types.ObjectId(),
          name: "Product unavailable",
          price: 0
        };
      }
    });
  }
  next();
});

const Cart = mongoose.model('Cart', cartSchema);

module.exports = Cart;