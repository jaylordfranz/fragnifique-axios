const mongoose = require('mongoose');
const validator = require('validator');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please enter your name'],
        maxLength: [30, 'Your name cannot exceed 30 characters']
    },
    email: {
        type: String,
        required: [true, 'Please enter your email'],
        unique: true,
        validate: [validator.isEmail, 'Please enter valid email address']
    },
    password: {
        type: String,
        required: [true, 'Please enter your password'],
        minlength: [6, 'Your password must be longer than 6 characters'],
        select: false
    },
    avatar: {
        public_id: {
            type: String,
        },
        url: {
            type: String,
        }
    },
    role: {
        type: String,
        default: 'user'
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    notificationTokens: [{
        type: String,
        trim: true,
        index: true
    }],
    resetPasswordToken: String,
    resetPasswordExpire: Date
});

// Hash password before saving
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) {
        next()
    }
    this.password = await bcrypt.hash(this.password, 10);
});

// Generate JWT token
userSchema.methods.getJwtToken = function () {
    return jwt.sign({ id: this._id }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRES_TIME
    });
}

// Compare password
userSchema.methods.comparePassword = async function (enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
}

// Add push token if not already present
userSchema.methods.addPushToken = async function (token) {
    if (!this.notificationTokens.includes(token)) {
        this.notificationTokens.push(token);
        await this.save();
    }
    return this;
}

// Remove push token
userSchema.methods.removePushToken = async function (token) {
    this.notificationTokens = this.notificationTokens.filter(t => t !== token);
    await this.save();
    return this;
}

// Clean duplicate tokens
userSchema.methods.cleanDuplicateTokens = async function () {
    const uniqueTokens = [...new Set(this.notificationTokens)];
    if (uniqueTokens.length !== this.notificationTokens.length) {
        this.notificationTokens = uniqueTokens;
        await this.save();
    }
    return this;
}

module.exports = mongoose.model('User', userSchema);