const mongoose = require('mongoose');
const productSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please enter name'],
        trim: true,
        maxLength: [100, 'Product name cannot exceed 100 characters']
    },
    description: {
        type: String,
        required: [true, 'Please enter product description'],
    },
    price: {
        type: Number,
        required: [true, 'Please enter product price'],
        default: 0.0
    },
    stock: {
        type: Number,
        required: [true, 'Please enter product stock'],
        default: 0,
        min: [0, 'Stock cannot be negative']
    },
    images: [
        {
            public_id: {
                type: String,
                required: true
            },
            url: {
                type: String,
                required: true
            }
        }
    ],
    ratings: {
        type: Number,
        default: 0
    },
    numOfReviews: {
        type: Number,
        default: 0
    },
    reviews: [
        {
            user: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'User',
                required: true
            },
            name: {
                type: String,
                required: true
            },
            rating: {
                type: Number,
                required: true
            },
            comment: {
                type: String,
                required: true
            }
        }
    ],
    categories: {
        type: [String],
        enum: ['For Him', 'For Her', 'Unisex', 'Daily', 'Formal', 'Casual'],
        required: true
    },
    salesCount: {
        type: Number,
        default: 0
      },
      
      salesStatus: {
        type: String,
        enum: ['New', 'Regular', 'Popular', 'Hot', 'Best Seller'],
        default: 'New'
      },
    createdAt: {
        type: Date,
        default: Date.now
    },
   
    promotions: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Promotion'
  }],

  discountedPrice: {
    type: Number
  }
});

const reviewSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    name: {
        type: String,
        required: true
    },
    rating: {
        type: Number,
        required: true,
        min: 1,
        max: 5
    },
    comment: {
        type: String,
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});
module.exports = mongoose.model('Product', productSchema);