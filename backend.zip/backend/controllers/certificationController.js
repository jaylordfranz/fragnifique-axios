const Certification = require('../models/Certification');
const APIFeatures = require('../utils/apiFeatures');
const cloudinary = require("cloudinary").v2;

exports.getCertifications = async (req, res) => {
    try {
        const resPerPage = 4;
        const certificationsCount = await Certification.countDocuments();
        const apiFeatures = new APIFeatures(Certification.find(), req.query).search().filter();
        apiFeatures.pagination(resPerPage);
        const certifications = await apiFeatures.query;
        let filteredCertificationsCount = certifications.length;

        return res.status(200).json({
            success: true,
            certifications,
            filteredCertificationsCount,
            resPerPage,
            certificationsCount
        });
    } catch (error) {
        return res.status(500).json({ message: "Error loading Certifications", error });
    }
};


exports.getAdminCertifications= async (req, res, next) => {

    const certifications = await Certification.find();
    if (!certifications) {
        return res.status(404).json({
            success: false,
            message: 'Certification not found'
        })
    }
    return res.status(200).json({
        success: true,
        certifications
    })

}


exports.getSingleCertification = async (req, res) => {
    try {
        const certification = await Certification.findById(req.params.id);
        if (!certification) {
            return res.status(404).json({ success: false, message: "Certification not found" });
        }
        return res.status(200).json({ success: true, certification });
    } catch (error) {
        return res.status(500).json({ message: "Error fetching Certification", error });
    }
};

exports.newCertification = async (req, res) => {
     try {
    
            if (!req.files || req.files.length === 0) {
                return res.status(400).json({ success: false, message: "No images uploaded." });
            }
    
            let imagesLinks = [];
    
            for (const file of req.files) {
    
                try {
                    const result = await cloudinary.uploader.upload_stream(
                        { folder: "certifications", width: 500, crop: "scale" },
                        (error, result) => {
                            if (error) {
                                console.error("Cloudinary Upload Error:", error);
                                return res.status(500).json({ success: false, message: "Error uploading images to Cloudinary." });
                            }
                            imagesLinks.push({ public_id: result.public_id, url: result.secure_url });
    
                            if (imagesLinks.length === req.files.length) {
                                req.body.images = imagesLinks;
                                req.body.user = req.user.id;
    
                                Certification.create(req.body)
                                    .then(() => res.status(201).json({ success: true }))
                                    .catch((err) => res.status(400).json({ success: false, message: "certification not created." }));
                            }
                        }
                    ).end(file.buffer); 
    
                } catch (error) {
                    console.error("Cloudinary Upload Error:", error);
                    return res.status(500).json({ success: false, message: "Error uploading images to Cloudinary." });
                }
            }
    
        } catch (error) {
            console.error("Server Error:", error);
            res.status(500).json({ success: false, message: "Internal Server Error." });
        }
};

exports.updateCertification = async (req, res) => {
    let certification = await Certification.findById(req.params.id);
    
        if (!certification) {
            return res.status(404).json({
                success: false,
                message: 'certification not found'
            });
        }
    
        if (req.files && req.files.length > 0) {
            for (let i = 0; i < certification.images.length; i++) {
                await cloudinary.uploader.destroy(certification.images[i].public_id);
            }
    
            let imagesLinks = [];
    
            for (const file of req.files) {
                try {
                    const result = await new Promise((resolve, reject) => {
                        const uploadStream = cloudinary.uploader.upload_stream(
                            { folder: 'certifications', width: 500, crop: 'scale' },
                            (error, result) => {
                                if (error) reject(error);
                                else resolve(result);
                            }
                        );
                        uploadStream.end(file.buffer);
                    });
    
                    imagesLinks.push({
                        public_id: result.public_id,
                        url: result.secure_url
                    });
    
                } catch (error) {
                    console.error("Cloudinary Upload Error:", error);
                    return res.status(500).json({ success: false, message: "Error uploading images to Cloudinary." });
                }
            }
    
            req.body.images = imagesLinks; 
        } else {
            req.body.images = certification.images;
        }
    
        certification = await Certification.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true,
            useFindAndModify: false
        });
    
        return res.status(200).json({
            success: true,
            certification
        });
};

exports.deleteCertification = async (req, res) => {
    try {
        const certification = await Certification.findByIdAndDelete(req.params.id);
        if (!certification) {
            return res.status(404).json({ success: false, message: "Certification not found" });
        }
        return res.status(200).json({ success: true, message: "Certification deleted" });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Error deleting certification", error });
    }
};
