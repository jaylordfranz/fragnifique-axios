const Cart = require('../models/Cart');
const Product = require('../models/Product');

// Add item to cart
exports.addToCart = async (req, res) => {
  const { productId, quantity } = req.body;
  const userId = req.user.id; // User ID from authenticated user

  try {
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    if (quantity > product.stock) {
      return res.status(400).json({ success: false, message: 'Not enough stock' });
    }

    let cart = await Cart.findOne({ user: userId });

    if (!cart) {
      // If cart doesn't exist, create a new one
      cart = new Cart({
        user: userId,
        items: [{ product: productId, quantity }],
      });
    } else {
      // If cart exists, update the quantity or add a new product
      const itemIndex = cart.items.findIndex((item) => item.product.toString() === productId);

      if (itemIndex >= 0) {
        // Update quantity if product is already in cart
        cart.items[itemIndex].quantity += quantity;
      } else {
        // Add new product to the cart
        cart.items.push({ product: productId, quantity });
      }
    }

    await cart.save();

    res.status(200).json({ success: true, message: 'Item added to cart', cart });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

exports.getCart = async (req, res) => {
  const userId = req.user.id; // User ID from authenticated user
  try {
    const cart = await Cart.findOne({ user: userId }).populate('items.product');
    if (!cart) {
      return res.status(404).json({ success: false, message: 'Cart not found' });
    }
    
    // Verify each product exists and create fallback for deleted products
    const validItems = [];
    for (const item of cart.items) {
      if (!item.product || typeof item.product === 'string') {
        // Product not found - mark as offline
        item.isOffline = true;
        item.product = {
          _id: item.product,
          name: "Product unavailable",
          price: 0
        };
      }
      validItems.push(item);
    }
    // Replace cart.items with validItems
    cart.items = validItems;
    
    res.status(200).json({ success: true, cart });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Remove item from cart
exports.removeFromCart = async (req, res) => {
  const { productId } = req.body;
  const userId = req.user.id; // User ID from authenticated user

  try {
    const cart = await Cart.findOne({ user: userId });

    if (!cart) {
      return res.status(404).json({ success: false, message: 'Cart not found' });
    }

    cart.items = cart.items.filter((item) => item.product.toString() !== productId);
    await cart.save();

    res.status(200).json({ success: true, message: 'Item removed from cart', cart });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

exports.clearCart = async (req, res) => {
  const userId = req.user.id;
  try {
    // Complete replacement of the cart instead of just emptying items array
    await Cart.findOneAndDelete({ user: userId });
    
    res.status(200).json({ success: true, message: 'Cart cleared successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};
