const User = require("../models/user");
const cloudinary = require("cloudinary").v2;
const sendToken = require("../utils/jwtToken");

exports.registerUser = async (req, res, next) => {
    try {
        console.log("Registration request received:", {
            body: { ...req.body, password: '[HIDDEN]' },
            file: req.file ? "File received" : "No file"
        });
        
        // Validate inputs
        if (!req.body.name || !req.body.email || !req.body.password) {
            return res.status(400).json({ error: "Missing required fields" });
        }
        
        if (!req.file || !req.file.buffer) {
            return res.status(400).json({ error: "No image file uploaded" });
        }

        // Check if user already exists
        const existingUser = await User.findOne({ email: req.body.email });
        if (existingUser) {
            return res.status(400).json({ error: "User with this email already exists" });
        }

        console.log("Uploading file to Cloudinary...");
        try {
            const result = await new Promise((resolve, reject) => {
                const stream = cloudinary.uploader.upload_stream(
                    { folder: "avatars", width: 150, crop: "scale" },
                    (error, result) => {
                        if (error) {
                            console.error("Cloudinary Upload Error:", error);
                            reject(error);
                        } else {
                            console.log("Cloudinary Upload Success");
                            resolve(result);
                        }
                    }
                );
                stream.end(req.file.buffer);
            });

            console.log("Creating user in database");
            const { name, email, password } = req.body;
            const user = await User.create({
                name,
                email,
                password,
                avatar: {
                    public_id: result.public_id,
                    url: result.secure_url,
                },
            });

            console.log("User created successfully, sending token");
            sendToken(user, 200, res);
        } catch (uploadError) {
            console.error("Error in upload process:", uploadError);
            return res.status(500).json({ error: "Image upload failed" });
        }
    } catch (error) {
        console.error("Registration error:", error);
        res.status(500).json({ error: error.message || "Registration failed" });
    }
};

exports.loginUser = async (req, res, next) => {
    const { email, password } = req.body;

    let user = await User.findOne({ email }).select('+password')
    if (!user) {
        return res.status(401).json({ message: 'Invalid Email or Password' })
    }

    const isPasswordMatched = await user.comparePassword(password);
    if (!isPasswordMatched) {
        return res.status(401).json({ message: 'Invalid Email or Password' })
    }
    sendToken(user, 200, res)
}

exports.logout = async (req, res, next) => {
    // Remove the current device's push token if provided
    if (req.body.pushToken) {
        await User.findByIdAndUpdate(
            req.user.id,
            { $pull: { notificationTokens: req.body.pushToken } }
        );
    }

    res.cookie('token', null, {
        expires: new Date(Date.now()),
        httpOnly: true
    })

    res.status(200).json({
        success: true,
        message: 'Logged out'
    })
}

exports.getUserProfile = async (req, res, next) => {
    const user = await User.findById(req.user.id);

    return res.status(200).json({
        success: true,
        user
    })
}

exports.updateProfile = async (req, res, next) => {
    try {
        const newUserData = {
            name: req.body.name,
            email: req.body.email
        };

        if (req.body.avatar && req.body.avatar !== '') {
            let user = await User.findById(req.user.id);
            
            if (user.avatar && user.avatar.public_id) {
                const image_id = user.avatar.public_id;
                console.log("Removing old avatar from Cloudinary...");

                const destroyResult = await cloudinary.v2.uploader.destroy(image_id);
                console.log("Old avatar removed:", destroyResult);
            }

            console.log("Uploading new avatar to Cloudinary...");
            const result = await cloudinary.v2.uploader.upload(req.body.avatar, {
                folder: 'avatars',
                width: 150,
                crop: "scale"
            });

            newUserData.avatar = {
                public_id: result.public_id,
                url: result.secure_url
            };
        }

        const user = await User.findByIdAndUpdate(req.user.id, newUserData, {
            new: true,
            runValidators: true,
        });

        if (!user) {
            return res.status(401).json({ message: 'User Not Updated' });
        }

        return res.status(200).json({
            success: true,
            user
        });
    } catch (error) {
        console.error("Error during profile update:", error);
        return res.status(500).json({ error: error.message });
    }
};

exports.updatePassword = async (req, res, next) => {
    try {
        const { oldPassword, password } = req.body;

        if (!oldPassword || !password) {
            return res.status(400).json({ message: "Please provide both old and new passwords." });
        }

        const user = await User.findById(req.user.id).select('+password');

        if (!user) {
            return res.status(404).json({ message: "User not found." });
        }

        const isMatched = await user.comparePassword(oldPassword);
        if (!isMatched) {
            return res.status(400).json({ message: "Old password is incorrect." });
        }

        user.password = password;
        await user.save();

        const token = user.getJwtToken();

        return res.status(200).json({
            success: true,
            user,
            token,
        });
    } catch (error) {
        console.error("Error in updatePassword:", error);
        return res.status(500).json({ message: error.message });
    }
};

exports.savePushToken = async (req, res) => {
    try {
        const { token } = req.body;
        
        if (!token) {
            return res.status(400).json({ success: false, message: 'No token provided' });
        }
        
        const user = await User.findById(req.user.id);
        
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }
        
        // Add the token if not already present
        if (!user.notificationTokens.includes(token)) {
            user.notificationTokens.push(token);
            await user.save();
        }
        
        // Clean up any duplicate tokens
        const uniqueTokens = [...new Set(user.notificationTokens)];
        if (uniqueTokens.length !== user.notificationTokens.length) {
            user.notificationTokens = uniqueTokens;
            await user.save();
        }
        
        return res.status(200).json({ 
            success: true, 
            message: 'Token saved successfully',
            tokens: user.notificationTokens
        });
    } catch (error) {
        console.error('Push token save error:', error);
        return res.status(500).json({ success: false, message: 'Failed to save token' });
    }
};

exports.removePushToken = async (req, res) => {
    try {
        const { token } = req.body;
        
        if (!token) {
            return res.status(400).json({ success: false, message: 'No token provided' });
        }
        
        const user = await User.findByIdAndUpdate(
            req.user.id,
            { $pull: { notificationTokens: token } },
            { new: true }
        );
        
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }
        
        return res.status(200).json({ 
            success: true, 
            message: 'Token removed successfully',
            tokens: user.notificationTokens
        });
    } catch (error) {
        console.error('Push token remove error:', error);
        return res.status(500).json({ success: false, message: 'Failed to remove token' });
    }
};

exports.cleanStaleTokens = async (req, res) => {
    try {
        // This would typically be called from a scheduled job, not directly from client
        const users = await User.find({ notificationTokens: { $exists: true, $not: { $size: 0 } } });
        
        let totalRemoved = 0;
        const results = await Promise.all(
            users.map(async (user) => {
                const originalCount = user.notificationTokens.length;
                
                // In a real implementation, you would verify each token with your push service
                // Here we'll just simulate removing tokens older than 30 days
                const now = new Date();
                const thresholdDate = new Date(now.setDate(now.getDate() - 30));
                
                // Filter tokens (in a real app, you'd verify each token)
                user.notificationTokens = user.notificationTokens.filter(token => {
                    // This is a simplified example - in reality you'd need to track token dates
                    // or verify each token with your push service
                    return Math.random() > 0.1; // Randomly keep 90% to simulate cleanup
                });
                
                const removed = originalCount - user.notificationTokens.length;
                if (removed > 0) {
                    await user.save();
                    totalRemoved += removed;
                }
                
                return {
                    userId: user._id,
                    removed,
                    remaining: user.notificationTokens.length
                };
            })
        );
        
        return res.status(200).json({
            success: true,
            message: `Cleaned up stale tokens from ${users.length} users`,
            totalRemoved,
            details: results
        });
    } catch (error) {
        console.error('Token cleanup error:', error);
        return res.status(500).json({ success: false, message: 'Failed to clean tokens' });
    }
};