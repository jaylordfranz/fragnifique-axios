// controllers/reviewController.js
const mongoose = require('mongoose');
const { isValidObjectId } = mongoose;
const Review = require('../models/Review');
const Product = require('../models/Product');
const User = require('../models/user');

// Create a new review
exports.createReview = async (req, res) => {
  try {
    const { productId, rating, comment } = req.body;
    const userId = req.user._id; // Assuming user is authenticated and available in req.user

    // Validate input
    if (!productId || !rating) {
      return res.status(400).json({ message: 'Product ID and rating are required' });
    }

    // Validate MongoDB ObjectId
    if (!isValidObjectId(productId)) {
      return res.status(400).json({ message: 'Invalid product ID format' });
    }

    // Check if product exists
    const productExists = await Product.findById(productId);
    if (!productExists) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Check if user has already reviewed this product
    const existingReview = await Review.findOne({ productId, userId });
    if (existingReview) {
      return res.status(400).json({ message: 'You have already reviewed this product' });
    }

    // Create new review
    const newReview = new Review({
      productId,
      userId,
      rating,
      comment: comment || ''
    });

    // Save the review
    const savedReview = await newReview.save();

    // Update product with new review data (calculate average rating)
    await updateProductRating(productId);

    res.status(201).json(savedReview);
  } catch (error) {
    console.error('Error creating review:', error);
    res.status(500).json({ message: 'Failed to create review', error: error.message });
  }
};

// Get all reviews for a product
exports.getProductReviews = async (req, res) => {
  try {
    const { productId } = req.params;
    const { page = 1, limit = 10 } = req.query;

    // Validate MongoDB ObjectId
    if (!isValidObjectId(productId)) {
      return res.status(400).json({ message: 'Invalid product ID format' });
    }

    // Calculate pagination values
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const pageLimit = parseInt(limit);

    // Find all reviews for the product with pagination
    const reviews = await Review.find({ productId })
      .populate('userId', 'name avatar') // Only get user name and avatar
      .sort({ createdAt: -1 }) // Most recent first
      .skip(skip)
      .limit(pageLimit);

    // Get total count for pagination info
    const totalReviews = await Review.countDocuments({ productId });

    res.status(200).json({
      reviews,
      pagination: {
        totalReviews,
        totalPages: Math.ceil(totalReviews / pageLimit),
        currentPage: parseInt(page),
        limit: pageLimit
      }
    });
  } catch (error) {
    console.error('Error fetching reviews:', error);
    res.status(500).json({ message: 'Failed to fetch reviews', error: error.message });
  }
};

// Get a review by ID
exports.getReviewById = async (req, res) => {
  try {
    const { reviewId } = req.params;
    
    // Validate MongoDB ObjectId
    if (!isValidObjectId(reviewId)) {
      return res.status(400).json({ message: 'Invalid review ID format' });
    }
    
    const review = await Review.findById(reviewId)
      .populate('userId', 'name avatar')
      .populate('productId', 'name images');
    
    if (!review) {
      return res.status(404).json({ message: 'Review not found' });
    }
    
    res.status(200).json(review);
  } catch (error) {
    console.error('Error fetching review:', error);
    res.status(500).json({ message: 'Failed to fetch review', error: error.message });
  }
};

// Update a review
exports.updateReview = async (req, res) => {
  try {
    const { reviewId } = req.params;
    const { rating, comment } = req.body;
    const userId = req.user._id;

    // Validate MongoDB ObjectId
    if (!isValidObjectId(reviewId)) {
      return res.status(400).json({ message: 'Invalid review ID format' });
    }

    // Find the review
    const review = await Review.findById(reviewId);
    
    if (!review) {
      return res.status(404).json({ message: 'Review not found' });
    }
    
    // Check if the review belongs to the user
    if (review.userId.toString() !== userId.toString()) {
      return res.status(403).json({ message: 'You can only update your own reviews' });
    }
    
    // Update review fields
    if (rating) review.rating = rating;
    if (comment !== undefined) review.comment = comment;
    
    // Update the updatedAt timestamp if it exists in the schema
    if (review.schema?.paths?.updatedAt) {
      review.updatedAt = Date.now();
    }
    
    // Save updated review
    const updatedReview = await review.save();
    
    // Update product with new review data
    await updateProductRating(review.productId);
    
    res.status(200).json(updatedReview);
  } catch (error) {
    console.error('Error updating review:', error);
    res.status(500).json({ message: 'Failed to update review', error: error.message });
  }
};

// Delete a review
exports.deleteReview = async (req, res) => {
  try {
    const { reviewId } = req.params;
    const userId = req.user._id;
    
    // Validate MongoDB ObjectId
    if (!isValidObjectId(reviewId)) {
      return res.status(400).json({ message: 'Invalid review ID format' });
    }
    
    // Find the review
    const review = await Review.findById(reviewId);
    
    if (!review) {
      return res.status(404).json({ message: 'Review not found' });
    }
    
    // Check if the review belongs to the user or user is admin
    if (review.userId.toString() !== userId.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'You can only delete your own reviews' });
    }
    
    // Save productId before deleting to update ratings
    const productId = review.productId;
    
    // Delete the review
    await Review.findByIdAndDelete(reviewId);
    
    // Update product ratings
    await updateProductRating(productId);
    
    res.status(200).json({ message: 'Review deleted successfully' });
  } catch (error) {
    console.error('Error deleting review:', error);
    res.status(500).json({ message: 'Failed to delete review', error: error.message });
  }
};

// Get reviews by user
exports.getUserReviews = async (req, res) => {
  try {
    const userId = req.user._id;
    const { page = 1, limit = 10 } = req.query;
    
    // Calculate pagination values
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const pageLimit = parseInt(limit);
    
    const reviews = await Review.find({ userId })
      .populate('productId', 'name images price')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(pageLimit);
    
    // Get total count for pagination info
    const totalReviews = await Review.countDocuments({ userId });
    
    res.status(200).json({
      reviews,
      pagination: {
        totalReviews,
        totalPages: Math.ceil(totalReviews / pageLimit),
        currentPage: parseInt(page),
        limit: pageLimit
      }
    });
  } catch (error) {
    console.error('Error fetching user reviews:', error);
    res.status(500).json({ message: 'Failed to fetch user reviews', error: error.message });
  }
};

// Helper function to update product rating
async function updateProductRating(productId) {
  try {
    // Validate MongoDB ObjectId
    if (!isValidObjectId(productId)) {
      throw new Error('Invalid product ID format');
    }
    
    // Find all reviews for the product
    const productReviews = await Review.find({ productId });
    
    if (productReviews.length === 0) {
      // No reviews, set rating to 0
      await Product.findByIdAndUpdate(productId, { 
        rating: 0,
        numReviews: 0
      });
      return;
    }
    
    // Calculate average rating
    const totalRating = productReviews.reduce((sum, review) => sum + review.rating, 0);
    const averageRating = totalRating / productReviews.length;
    
    // Update product
    await Product.findByIdAndUpdate(productId, {
      rating: averageRating.toFixed(1),
      numReviews: productReviews.length
    });
  } catch (error) {
    console.error('Error updating product rating:', error);
    throw error;
  }
}