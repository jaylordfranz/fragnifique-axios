const Product = require('../models/Product');


const APIFeatures = require('../utils/apiFeatures');
const cloudinary = require("cloudinary").v2;

// In your product controller file

exports.getProducts = async (req, res) => {
    try {
      const resPerPage = 10;
      const productsCount = await Product.countDocuments();
      
      const apiFeatures = new APIFeatures(Product.find().populate('promotions'), req.query)
        .search()
        .filter();
      
      apiFeatures.pagination(resPerPage);
      let products = await apiFeatures.query;
      let filteredProductsCount = products.length;
      
      // Process products to include active discounts and sales information
      products = products.map(product => {
        const productObj = product.toObject();
        
        // Find active promotion
        const activePromotion = product.promotions?.find(promo =>
          new Date(promo.startDate) <= new Date() &&
          new Date(promo.endDate) >= new Date()
        );
        
        if (activePromotion) {
          productObj.discount = activePromotion.discountPercentage;
          productObj.discountedPrice = product.price * (1 - (activePromotion.discountPercentage / 100));
          productObj.discountEndDate = activePromotion.endDate;
        }
        
        // Include sales information
        productObj.salesCount = product.salesCount || 0;
        productObj.salesStatus = product.salesStatus || 'New';
        
        return productObj;
      });
      
      return res.status(200).json({
        success: true,
        products,
        filteredProductsCount,
        resPerPage,
        productsCount,
      });
    } catch (error) {
      console.error("Error in getProducts:", error);
      return res.status(500).json({ success: false, message: "Internal server error" });
    }
  };
  
exports.getSingleProduct = async (req, res, next) => {
    try {
        // Populate promotions to get discount details
        const product = await Product.findById(req.params.id).populate('promotions');
        
        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Product not found'
            });
        }

        const productObj = product.toObject();
        
        // Find active promotion
        const activePromotion = product.promotions?.find(promo => 
            new Date(promo.startDate) <= new Date() && 
            new Date(promo.endDate) >= new Date()
        );
        
        if (activePromotion) {
            productObj.discount = activePromotion.discountPercentage;
            productObj.discountedPrice = product.price * (1 - (activePromotion.discountPercentage / 100));
            productObj.discountEndDate = activePromotion.endDate;
        }

        return res.status(200).json({
            success: true,
            product: productObj
        });
    } catch (error) {
        console.error("Error in getSingleProduct:", error);
        return res.status(500).json({ success: false, message: "Internal server error" });
    }
};

exports.getAdminProducts = async (req, res) => {
    const products = await Product.find();
    if (!products) {
        return res.status(404).json({
            success: false,
            message: 'Product not found'
        });
    }
    return res.status(200).json({
        success: true,
        products
    });
};


// Admin route: Delete a product
exports.deleteProduct = async (req, res) => {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) {
        return res.status(404).json({
            success: false,
            message: 'Product not found'
        });
    }
    return res.status(200).json({
        success: true,
        message: 'Product deleted'
    });
};


// Admin route: Create a new product
exports.newProduct = async (req, res) => {
    try {
        // Check for required categories
        if (!req.body.categories) {  // Changed from category to categories
            return res.status(400).json({ success: false, message: "Product categories are required." });
        }
       
        // Handle image upload
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ success: false, message: "No images uploaded." });
        }
       
        let imagesLinks = [];
       
        // Process each image one by one
        for (let i = 0; i < req.files.length; i++) {
            const file = req.files[i];
           
            try {
                const result = await new Promise((resolve, reject) => {
                    const uploadStream = cloudinary.uploader.upload_stream(
                        { folder: "products", width: 500, crop: "scale" },
                        (error, result) => {
                            if (error) reject(error);
                            else resolve(result);
                        }
                    );
                    uploadStream.end(file.buffer);
                });
               
                imagesLinks.push({
                    public_id: result.public_id,
                    url: result.secure_url
                });
               
                // When all images are processed, create the product
                if (imagesLinks.length === req.files.length) {
                    req.body.images = imagesLinks;
                    req.body.user = req.user.id;
                   
                    const product = await Product.create(req.body);
                    res.status(201).json({
                        success: true,
                        product
                    });
                }
            } catch (error) {
                console.error("Cloudinary Upload Error:", error);
                return res.status(500).json({ success: false, message: "Error uploading images to Cloudinary." });
            }
        }
    } catch (error) {
        console.error("Server Error:", error);
        res.status(500).json({ success: false, message: "Internal Server Error." });
    }
};


// Admin route: Update a product
exports.updateProduct = async (req, res) => {
    try {
        let product = await Product.findById(req.params.id);
       
        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Product not found'
            });
        }
       
        // Handle image updates
        if (req.files && req.files.length > 0) {
            // Delete old images from Cloudinary
            for (let i = 0; i < product.images.length; i++) {
                await cloudinary.uploader.destroy(product.images[i].public_id);
            }
           
            // Upload new images
            let imagesLinks = [];
           
            for (const file of req.files) {
                try {
                    const result = await new Promise((resolve, reject) => {
                        const uploadStream = cloudinary.uploader.upload_stream(
                            { folder: 'products', width: 500, crop: 'scale' },
                            (error, result) => {
                                if (error) reject(error);
                                else resolve(result);
                            }
                        );
                        uploadStream.end(file.buffer);
                    });
                   
                    imagesLinks.push({
                        public_id: result.public_id,
                        url: result.secure_url
                    });
                } catch (error) {
                    console.error("Cloudinary Upload Error:", error);
                    return res.status(500).json({ success: false, message: "Error uploading images to Cloudinary." });
                }
            }
           
            req.body.images = imagesLinks;
        } else {
            req.body.images = product.images;
        }
       
        // Update the product
        product = await Product.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true,
            useFindAndModify: false
        });
       
        return res.status(200).json({
            success: true,
            product
        });
    } catch (error) {
        console.error("Error:", error);
        return res.status(500).json({ success: false, message: "Internal Server Error." });
    }
};


// User and Admin route: Get single product details
exports.getSingleProduct = async (req, res, next) => {
    const product = await Product.findById(req.params.id);
    if (!product) {
        return res.status(404).json({
            success: false,
            message: 'Product not found'
        });
    }
    return res.status(200).json({
        success: true,
        product
    });
};


// Create a product review (User)
exports.createProductReview = async (req, res) => {
    try {
      const { rating, comment } = req.body;
      const { productId } = req.params;
      
      if (!productId) return res.status(400).json({ success: false, message: "Product ID is required" });
      if (!rating || !comment) return res.status(400).json({ success: false, message: "Rating and comment are required" });
      
      const product = await Product.findById(productId);
      if (!product) return res.status(404).json({ success: false, message: "Product not found" });
      
      const review = {
        user: req.user._id,
        name: req.user.name,
        rating: Number(rating),
        comment
      };
      
      const isReviewed = product.reviews.find(r => r.user.toString() === req.user._id.toString());
      
      if (isReviewed) {
        // Update existing review
        product.reviews.forEach(review => {
          if (review.user.toString() === req.user._id.toString()) {
            review.comment = comment;
            review.rating = rating;
          }
        });
      } else {
        // Add new review
        product.reviews.push(review);
        product.numOfReviews = product.reviews.length;
      }
      
      // Recalculate average rating
      product.ratings = product.reviews.reduce((acc, item) => item.rating + acc, 0) / product.reviews.length;
      
      await product.save({ validateBeforeSave: false });
      return res.status(200).json({ success: true, message: "Review submitted successfully" });
    } catch (error) {
      console.error("Error in createProductReview:", error);
      return res.status(500).json({ success: false, message: "Internal Server Error" });
    }
  };

  exports.getUserReviewForProduct = async (req, res) => {
    try {
      const { productId } = req.params;
      
      if (!productId) return res.status(400).json({ success: false, message: "Product ID is required" });
      
      const product = await Product.findById(productId);
      if (!product) return res.status(404).json({ success: false, message: "Product not found" });
      
      // Find if the user has already reviewed this product
      const userReview = product.reviews.find(r => r.user.toString() === req.user._id.toString());
      
      return res.status(200).json({
        success: true,
        review: userReview || null
      });
    } catch (error) {
      console.error("Error in getUserReviewForProduct:", error);
      return res.status(500).json({ success: false, message: "Internal Server Error" });
    }
  };


// Get product reviews (User)
exports.getProductReviews = async (req, res, next) => {
    try {
        const { productId } = req.params;


        if (!productId) {
            return res.status(400).json({ success: false, message: "Product ID is required." });
        }


        const product = await Product.findById(productId);


        if (!product) {
            return res.status(404).json({ success: false, message: "Product not found." });
        }


        return res.status(200).json({
            success: true,
            reviews: product.reviews
        });


    } catch (error) {
        console.error("Error in getProductReviews:", error);
        return res.status(500).json({ success: false, message: "Internal server error." });
    }
};


// Delete a review (Admin)
exports.deleteReview = async (req, res, next) => {
    try {
        const { reviewId } = req.params;


        if (!reviewId) {
            return res.status(400).json({ success: false, message: "Review ID is required." });
        }


        const product = await Product.findOne({ "reviews._id": reviewId });


        if (!product) {
            return res.status(404).json({ success: false, message: "Review not found." });
        }


        product.reviews = product.reviews.filter(review => review._id.toString() !== reviewId);
        product.numOfReviews = product.reviews.length;
        product.ratings = product.reviews.length > 0
            ? product.reviews.reduce((acc, item) => item.rating + acc, 0) / product.reviews.length
            : 0;


        await product.save({ validateBeforeSave: false });


        return res.status(200).json({ success: true, message: "Review deleted successfully!" });


    } catch (error) {
        console.error("Error in deleteReview:", error);
        return res.status(500).json({ success: false, message: "Internal server error." });
    }
};
