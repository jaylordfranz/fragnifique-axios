const Promotion = require('../models/Promotion');
const Product = require('../models/Product');
const User = require('../models/user');


// Helper function to update product price
const updateProductPrice = async (productId, discountPercentage, promotionId) => {
  const product = await Product.findById(productId);
  if (!product) {
    console.error('Product not found for ID:', productId);
    return null;
  }
  
  const discountedPrice = product.price * (1 - (discountPercentage / 100));
  return Product.findByIdAndUpdate(
    productId, 
    { 
      discountedPrice,
      $addToSet: { promotions: promotionId }
    },
    { new: true }
  );
};

// Send push notifications to all users
const sendPromotionNotification = async (promotion) => {
  try {
    const users = await User.find({ pushToken: { $exists: true } }).select('pushToken');
    if (users.length === 0) return;

    const messages = users.map(user => ({
      to: user.pushToken,
      sound: 'default',
      title: `🔥 ${promotion.title}`,
      body: `${promotion.discountPercentage}% OFF on ${promotion.product.name}!`,
      data: {
        type: 'promotion',
        promotionId: promotion._id,
        productId: promotion.product._id,
        screen: 'ProductDetail'
      }
    }));

    const chunks = expo.chunkPushNotifications(messages);
    for (const chunk of chunks) {
      await expo.sendPushNotificationsAsync(chunk);
    }
    console.log(`Sent ${users.length} promotion notifications`);
  } catch (error) {
    console.error('Error sending promotion notifications:', error);
  }
};

// Create Promotion
exports.createPromotion = async (req, res) => {
  try {
    const { productId, title, description, discountPercentage, endDate } = req.body;

    if (!productId || !title || !discountPercentage || !endDate) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields"
      });
    }

    const promotion = await Promotion.create({
      product: productId,
      title,
      description,
      discountPercentage,
      endDate: new Date(endDate),
      startDate: Date.now()
    });

    const updatedProduct = await updateProductPrice(productId, discountPercentage, promotion._id);
    
    // Populate product for notification
    const populatedPromotion = await Promotion.findById(promotion._id)
      .populate('product', 'name price');
    
    // Send push notifications
    await sendPromotionNotification(populatedPromotion);

    res.status(201).json({
      success: true,
      promotion
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get All Active Promotions
exports.getAllPromotions = async (req, res) => {
  try {
    const promotions = await Promotion.find({ isActive: true })
      .populate('product', 'name price images')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      promotions
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get Single Promotion
exports.getPromotion = async (req, res) => {
  try {
    const promotion = await Promotion.findById(req.params.id)
      .populate('product', 'name price images');

    if (!promotion) {
      return res.status(404).json({
        success: false,
        message: 'Promotion not found'
      });
    }

    res.status(200).json({
      success: true,
      promotion
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Update Promotion
exports.updatePromotion = async (req, res) => {
  try {
    const promotion = await Promotion.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    }).populate('product', 'name price');

    if (!promotion) {
      return res.status(404).json({
        success: false,
        message: 'Promotion not found'
      });
    }

    if (req.body.discountPercentage) {
      await updateProductPrice(promotion.product._id, req.body.discountPercentage, promotion._id);
      await sendPromotionNotification(promotion);
    }

    res.status(200).json({
      success: true,
      promotion
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Delete Promotion
exports.deletePromotion = async (req, res) => {
  try {
    const promotion = await Promotion.findByIdAndUpdate(
      req.params.id,
      { isActive: false },
      { new: true }
    );

    if (!promotion) {
      return res.status(404).json({
        success: false,
        message: 'Promotion not found'
      });
    }

    await Product.findByIdAndUpdate(promotion.product, {
      $pull: { promotions: promotion._id },
      $unset: { discountedPrice: 1 }
    });

    res.status(200).json({
      success: true,
      message: 'Promotion deactivated successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get Active Promotions
exports.getActivePromotions = async (req, res) => {
  try {
    const promotions = await Promotion.find({
      isActive: true,
      endDate: { $gt: new Date() }
    })
    .populate('product', 'name price images')
    .sort({ createdAt: -1 })
    .limit(5);

    res.status(200).json({
      success: true,
      promotions
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};