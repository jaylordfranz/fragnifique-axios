const User = require('../models/user');

exports.updateNotificationToken = async (req, res) => {
  try {
    const { token } = req.body;
    
    if (!token) {
      return res.status(400).json({
        success: false,
        message: 'Notification token is required'
      });
    }
    
    const user = await User.findById(req.user.id);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    // Check if token already exists to avoid duplicates
    if (!user.notificationTokens.includes(token)) {
      user.notificationTokens.push(token);
      await user.save();
    }
    
    return res.status(200).json({
      success: true,
      message: 'Notification token updated successfully'
    });
  } catch (error) {
    console.error('Update notification token error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update notification token',
      error: error.message
    });
  }
};