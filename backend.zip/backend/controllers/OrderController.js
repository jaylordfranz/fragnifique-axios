const Order = require('../models/Order');
const User = require('../models/user');
const Product = require('../models/Product');
const { sendNotification } = require('../utils/notificationService');
const { updateSalesStatus } = require('../utils/salesStatus');

// Create a new order
exports.createOrder = async (req, res) => {
  try {
    const { 
      items, 
      shippingAddress, 
      paymentMethod, 
      subtotal, 
      shippingFee, 
      tax, 
      totalAmount 
    } = req.body;
    
    if (!items || !items.length || !shippingAddress || !paymentMethod || !totalAmount) {
      return res.status(400).json({ 
        success: false, 
        message: 'Missing required order information' 
      });
    }
    
    // Check if all products have sufficient stock
    for (const item of items) {
      const product = await Product.findById(item.product);
      if (!product) {
        return res.status(404).json({
          success: false,
          message: `Product not found with id: ${item.product}`
        });
      }
      
      if (product.stock < item.quantity) {
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for product: ${product.name}`
        });
      }
    }
    
    const order = new Order({
      user: req.user.id,
      items,
      shippingAddress,
      paymentMethod,
      subtotal,
      shippingFee: shippingFee || 0,
      tax: tax || 0,
      totalAmount
    });
    
    const savedOrder = await order.save();
    
    // Update product stock after successful order creation
    try {
      await updateProductStock(items);
      // Update product sales count and status
      await updateProductSalesCount(items);
    } catch (error) {
      // If stock or sales update fails, delete the created order to maintain consistency
      await Order.findByIdAndDelete(savedOrder._id);
      return res.status(500).json({
        success: false,
        message: 'Failed to update product information',
        error: error.message
      });
    }
    
    const populatedOrder = await Order.findById(savedOrder._id)
      .populate('items.product', 'name price imageUrl');
    
    return res.status(201).json({
      success: true,
      order: populatedOrder,
      message: 'Order created successfully'
    });
  } catch (error) {
    console.error('Order creation error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to create order',
      error: error.message
    });
  }
};

// Get all orders for the authenticated user
exports.getUserOrders = async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user.id })
      .populate('items.product', 'name price imageUrl')
      .sort({ orderDate: -1 });
    
    return res.status(200).json({
      success: true,
      orders
    });
  } catch (error) {
    console.error('Get user orders error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch orders',
      error: error.message
    });
  }
};

// Get a single order by ID
exports.getOrderById = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('items.product', 'name price imageUrl');
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }
    
    if (order.user.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to view this order'
      });
    }
    
    return res.status(200).json({
      success: true,
      order
    });
  } catch (error) {
    console.error('Get order error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch order',
      error: error.message
    });
  }
};

// Update order by user
exports.updateOrder = async (req, res) => {
  try {
    const { orderStatus } = req.body;
    
    const order = await Order.findById(req.params.id);
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }
    
    // Check if the user is authorized to update this order
    if (order.user.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to update this order'
      });
    }
    
    // Update order status
    order.orderStatus = orderStatus;
    
    const updatedOrder = await order.save();
    
    return res.status(200).json({
      success: true,
      order: updatedOrder,
      message: 'Order status updated successfully'
    });
  } catch (error) {
    console.error('Update order error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update order',
      error: error.message
    });
  }
};

// Admin update order status
exports.adminUpdateOrderStatus = async (req, res) => {
  try {
    const { orderStatus, paymentStatus } = req.body;
    
    const order = await Order.findById(req.params.id);
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }
    
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized. Admin access required'
      });
    }
    
    const oldOrderStatus = order.orderStatus;
    
    // Update order statuses
    if (orderStatus) order.orderStatus = orderStatus;
    if (paymentStatus) order.paymentStatus = paymentStatus;
    
    const updatedOrder = await order.save();
    
    // Send notification if status changed
    if (oldOrderStatus !== orderStatus && orderStatus) {
      try {
        const notificationResult = await sendNotification(
          order.user,
          'Order Status Updated',
          `Your order #${order._id.toString().slice(-6)} is now ${orderStatus}`,
          { 
            orderId: order._id.toString(),
            screen: 'OrderDetails',
            status: orderStatus
          }
        );
        
        console.log('Notification result:', notificationResult);
        
        if (!notificationResult.success) {
          console.log(`Notification not sent: ${notificationResult.message}`);
        }
      } catch (error) {
        console.error('Failed to send notification:', error);
        // Don't fail the whole request if notification fails
      }
    }
    
    // Return populated order data
    const populatedOrder = await Order.findById(updatedOrder._id)
      .populate('items.product', 'name price imageUrl')
      .populate('user', 'name email');
    
    return res.status(200).json({
      success: true,
      order: populatedOrder,
      message: 'Order updated successfully'
    });
  } catch (error) {
    console.error('Admin update order error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update order',
      error: error.message
    });
  }
};

// Get all orders (admin only)
exports.getAllOrders = async (req, res) => {
  try {
    // Check if user is admin - already handled by middleware, but good to be safe
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized. Admin access required'
      });
    }
    
    const orders = await Order.find()
      .populate('items.product', 'name price imageUrl')
      .populate('user', 'name email')
      .sort({ orderDate: -1 });
    
    return res.status(200).json({
      success: true,
      orders
    });
  } catch (error) {
    console.error('Get all orders error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch orders',
      error: error.message
    });
  }
};

// Update product stock levels
const updateProductStock = async (items) => {
  try {
    for (const item of items) {
      await Product.findByIdAndUpdate(
        item.product,
        { $inc: { stock: -item.quantity } },
        { new: true, runValidators: true }
      );
    }
  } catch (error) {
    console.error('Error updating product stock:', error);
    throw new Error('Failed to update product stock');
  }
};

// Update product sales count and status
const updateProductSalesCount = async (items) => {
  try {
    for (const item of items) {
      const product = await Product.findById(item.product);
      if (product) {
        product.salesCount += item.quantity;
        product.salesStatus = updateSalesStatus(product.salesCount);
        await product.save();
      }
    }
  } catch (error) {
    console.error('Error updating product sales count:', error);
    throw new Error('Failed to update product sales count');
  }
};