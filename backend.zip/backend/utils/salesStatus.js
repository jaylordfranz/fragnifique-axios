const updateSalesStatus = (salesCount) => {
    if (salesCount >= 100) return 'Best Seller';
    if (salesCount >= 50) return 'Hot';
    if (salesCount >= 20) return 'Popular';
    if (salesCount >= 5) return 'Regular';
    return 'New';
  };
  
  module.exports = { updateSalesStatus };