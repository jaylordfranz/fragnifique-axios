const sendToken = (user, statusCode, res) => {
    // Create JWT token
    const token = user.getJwtToken();
    
    // For web clients, we still set the cookie (though mobile apps won't use it)
    const options = {
        expires: new Date(
            Date.now() + process.env.COOKIE_EXPIRES_TIME * 24 * 60 * 60 * 1000
        ),
        httpOnly: true,
        secure: true,
        sameSite: 'none',
    }
    
    // Set cookie and return the token in JSON response
    // Mobile clients will only use the token from the JSON response
    return res.status(statusCode).cookie('token', token, options).json({
        success: true,
        token,
        user
    });
}

module.exports = sendToken;