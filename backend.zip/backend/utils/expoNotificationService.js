const axios = require('axios');
const User = require('../models/user');

exports.sendPushNotification = async ({ title, body, data, userIds = [] }) => {
  try {
    let users;
    
    if (userIds.length > 0) {
      // Send to specific users
      users = await User.find({ 
        _id: { $in: userIds },
        notificationTokens: { $exists: true, $not: { $size: 0 } }
      });
    } else {
      // Send to all users
      users = await User.find({ 
        notificationTokens: { $exists: true, $not: { $size: 0 } }
      });
    }

    if (!users.length) {
      console.log('No users with notification tokens found');
      return;
    }

    // Collect all valid tokens
    const tokens = users.reduce((acc, user) => {
      return [...acc, ...user.notificationTokens];
    }, []);

    // Prepare messages
    const messages = tokens.map(token => ({
      to: token,
      sound: 'default',
      title,
      body,
      data: data || {}
    }));

    // Send notifications via Expo's push service
    const response = await axios.post('https://exp.host/--/api/v2/push/send', messages, {
      headers: {
        'Accept': 'application/json',
        'Accept-encoding': 'gzip, deflate',
        'Content-Type': 'application/json'
      }
    });

    // Check for failed tokens
    const failedTokens = [];
    response.data.data.forEach((item, index) => {
      if (item.status === 'error') {
        failedTokens.push(tokens[index]);
      }
    });

    // Clean up failed tokens
    if (failedTokens.length) {
      await User.updateMany(
        { notificationTokens: { $in: failedTokens } },
        { $pull: { notificationTokens: { $in: failedTokens } } }
      );
      console.log(`Cleaned up ${failedTokens.length} invalid tokens`);
    }

    return response.data;
  } catch (error) {
    console.error('Error sending Expo push notifications:', error);
    throw error;
  }
};