const { Expo } = require('expo-server-sdk');
const User = require('../models/user');

// Create a new Expo SDK client
const expo = new Expo();

/**
 * Send push notification to a specific user
 * @param {string} userId - The ID of the user to send notification to
 * @param {string} title - Notification title
 * @param {string} body - Notification body content
 * @param {object} data - Additional data to send with notification
 * @returns {object} Result of the operation
 */
const sendNotification = async (userId, title, body, data = {}) => {
    try {
        const user = await User.findById(userId);
        
        if (!user || !user.notificationTokens || user.notificationTokens.length === 0) {
            return { success: false, message: 'No notification tokens found' };
        }
        
        // Create messages array
        const messages = [];
        const validTokens = [];
        const invalidTokens = [];
        
        for (let pushToken of user.notificationTokens) {
            // First check that all your push tokens appear to be valid Expo push tokens
            if (!Expo.isExpoPushToken(pushToken)) {
                console.log(`Push token ${pushToken} is not a valid Expo push token`);
                invalidTokens.push(pushToken);
                continue;
            }
            
            validTokens.push(pushToken);
            
            // Construct a message (see https://docs.expo.io/push-notifications/sending-notifications/)
            messages.push({
                to: pushToken,
                sound: 'default',
                title,
                body,
                data,
                badge: 1,
                priority: 'high',
            });
        }
        
        // Remove invalid tokens from the user's document
        if (invalidTokens.length > 0) {
            user.notificationTokens = user.notificationTokens.filter(
                token => !invalidTokens.includes(token)
            );
            await user.save();
        }
        
        if (messages.length === 0) {
            return { success: false, message: 'No valid tokens to send to' };
        }
        
        // The Expo push notification service accepts batches of notifications
        // so that you don't need to send 1000 requests to send 1000 notifications
        const chunks = expo.chunkPushNotifications(messages);
        const tickets = [];
        
        // Send the chunks to the Expo push notification service
        for (let chunk of chunks) {
            try {
                const ticketChunk = await expo.sendPushNotificationsAsync(chunk);
                tickets.push(...ticketChunk);
                console.log('Push notification sent:', ticketChunk);
            } catch (error) {
                console.error('Error sending chunk of notifications:', error);
            }
        }
        
        // After sending notifications, check if any tickets have errors
        const receiptIds = [];
        for (let ticket of tickets) {
            if (ticket.id) {
                receiptIds.push(ticket.id);
            }
            if (ticket.status === 'error') {
                console.error(`There was an error sending a notification: ${ticket.message}`);
                if (ticket.details && ticket.details.error) {
                    // The error codes are listed in the Expo documentation:
                    // https://docs.expo.io/push-notifications/sending-notifications/#individual-errors
                    console.error(`The error code is ${ticket.details.error}`);
                }
            }
        }
        
        // Later (after 5-10 seconds), check for receipts
        if (receiptIds.length > 0) {
            // You should store receiptIds and check receipts later (not implemented here)
            console.log('Receipt IDs that should be checked later:', receiptIds);
        }
        
        return { success: true, tickets };
    } catch (error) {
        console.error('Notification service error:', error);
        return { success: false, error: error.message };
    }
};

module.exports = { sendNotification };